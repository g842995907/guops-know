from django.shortcuts import render

from rest_framework import generics

from common_framework.utils.constant import Status
from common_framework.views import find_menu

from common_web.decorators import login_required

from course.setting import api_settings

from course.models import Direction, Course
from course.cms.serializers import CourseSerializer

slug = api_settings.SLUG


@login_required
@find_menu(slug)
def list(request, **kwargs):
    context = kwargs.get('menu')
    directions = Direction.objects.filter(status=Status.NORMAL)

    language = getattr(request, 'LANGUAGE_CODE', u'zh-hans')
    rows = []
    if language == 'zh-hans':
        for row in directions:
                rows.append({'id': row.id, "name": row.cn_name})
    else:
        for row in directions:
            rows.append({'id': row.id, "name": row.en_name})
    context.update({"directions": rows, "search_type": None})
    return render(request, 'course/web/list.html', context)


@login_required
@find_menu(slug)
def theory_list(request, **kwargs):
    context = kwargs.get('menu')
    directions = Direction.objects.filter(status=Status.NORMAL)

    language = getattr(request, 'LANGUAGE_CODE', u'zh-hans')
    rows = []
    if language == 'zh-hans':
        for row in directions:
                rows.append({'id': row.id, "name": row.cn_name})
    else:
        for row in directions:
            rows.append({'id': row.id, "name": row.en_name})
    context.update({"directions": rows, "search_type": 0})
    return render(request, 'course/web/list.html', context)



@login_required
@find_menu(slug)
def experiment_list(request, **kwargs):
    context = kwargs.get('menu')
    directions = Direction.objects.filter(status=Status.NORMAL)

    language = getattr(request, 'LANGUAGE_CODE', u'zh-hans')
    rows = []
    if language == 'zh-hans':
        for row in directions:
                rows.append({'id': row.id, "name": row.cn_name})
    else:
        for row in directions:
            rows.append({'id': row.id, "name": row.en_name})
    context.update({"directions": rows, "search_type": 1})
    return render(request, 'course/web/list.html', context)


@login_required
@find_menu(slug)
def detail(request, **kwargs):
    template = 'course/web/detail.html'
    context = kwargs.get('menu')
    course_id = kwargs.get("course_id")
    context.update({"course_id": course_id})
    try:
        course = Course.objects.get(id=course_id)
        if course.type == 1:
            template = 'experiment/web/detail.html'
    except Exception, e:
        pass
    return render(request, template, context)


@login_required
@find_menu(slug)
def learn(request, **kwargs):
    template = 'course/web/learn.html'
    context = kwargs.get('menu')
    course_id = kwargs.get("course_id")
    context.update({"course_id": course_id})
    try:
        course = Course.objects.get(id=course_id)
        if course.type == 1:
            template = 'experiment/web/learn.html'
    except Exception, e:
        pass
    lesson_id = kwargs.get("lesson_id")
    if lesson_id:
        context.update({"lesson_id": lesson_id})
    return render(request, template, context)


@login_required
@find_menu(slug)
def task(request, **kwargs):
    context = kwargs.get('menu')
    task_hash = request.GET.get("task_hash")
    try:
        _, type_id = task_hash.split(".")
        context.update({"task_hash": task_hash,
                        "type_id": type_id})
        if int(type_id) == 0:
            template = "course/web/do_task.html"
        else:
            template = "course/web/do_task2.html"
    except Exception, e:
        template = 'course/web/task.html'
    return render(request, template, context)


@login_required
@find_menu(slug)
def pdf(request, **kwargs):
    context = kwargs.get('menu')
    pdf_url = request.GET.get("pdf_url")
    if pdf_url:
        context.update({"pdf_url": pdf_url})
    return render(request, 'course/web/pdf.html', context)


@login_required
@find_menu(slug)
def video(request, **kwargs):
    context = kwargs.get('menu')
    video_url = request.GET.get("video_url")
    if video_url:
        context.update({"video_url": video_url})
    return render(request, 'course/web/video.html', context)


@login_required
@find_menu(slug)
def note(request, **kwargs):
    context = kwargs.get('menu')
    course_id = request.GET.get("course_id")
    if course_id:
        context.update({"course_id": course_id})
    return render(request, 'course/web/note.html', context)


@login_required
@find_menu(slug)
def report(request, **kwargs):
    context = kwargs.get('menu')
    lesson_hash = request.GET.get("lesson_hash")
    if lesson_hash:
        context.update({"lesson_hash": lesson_hash})
    return render(request, 'experiment/web/report.html', context)


class CourseRecommandView(generics.ListAPIView):
    serializer_class = CourseSerializer

    def get_queryset(self):
        queryset = Course.objects.filter(status=Status.NORMAL).filter(public=1)
        # TODO: filter by direction
        if len(queryset) > 2:
            return queryset[:2]
        return queryset
