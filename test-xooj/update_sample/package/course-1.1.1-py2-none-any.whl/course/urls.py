from django.conf.urls import url, include


from common_framework.utils.rest.routers import get_default_router
from course.web import viewset, views

viewsets = (
    viewset.DirectionViewSet,
    viewset.CourseViewSet,
    viewset.LessonViewSet,
)

router = get_default_router(viewsets)

urlpatterns = [
    url(r'^api/', include(router.urls, namespace='api')),


    url(r'^list/$', views.list, name='list'),
    url(r'^theory_list/$', views.theory_list, name='theory_list'),
    url(r'^experiment_list/$', views.experiment_list, name='experiment_list'),
    url(r'^detail/(?P<course_id>[^/.]+)/$', views.detail, name='detail'),
    url(r'^learn/(?P<course_id>[^/.]+)/$', views.learn, name='learn'),
    url(r'^learn/(?P<course_id>[^/.]+)/(?P<lesson_id>[^/.]+)/$', views.learn, name='learn_lesson'),
    url(r'^task/$', views.task, name='task'),
    url(r'^pdf/$', views.pdf, name='pdf'),
    url(r'^video/$', views.video, name='video'),
    url(r'^note/$', views.note, name='note'),
    url(r'^report/$', views.report, name='report'),
    url(r'^recommand/$', views.CourseRecommandView.as_view(), name='recommand'),
]
