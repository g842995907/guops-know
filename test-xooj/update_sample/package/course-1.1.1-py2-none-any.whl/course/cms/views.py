# -*- coding: utf-8 -*-
import collections

from django.http import HttpResponse, JsonResponse
from django.http import QueryDict
from django.shortcuts import render
from django.urls import reverse
from django.utils.translation import gettext

from common_auth import api as auth_api
from common_auth.models import Classes
from common_cms import views as cms_views
from common_framework.utils.constant import Status

from course import models as course_model
from course.models import Course, Lesson
from practice.api import get_category_by_type

from x_note.models import Note


def get_difficulty():
    difficulty = collections.OrderedDict()
    difficulty[gettext('入门')] = 0
    difficulty[gettext('提高')] = 1
    difficulty[gettext('专家')] = 2

    return difficulty


def direction(request):
    return render(request, 'course/cms/directions.html')


def course(request):
    context = {
        'difficulty': get_difficulty(),
        'directions': course_model.Direction.objects.filter(status=Status.NORMAL)
    }
    return render(request, 'course/cms/courses.html', context)


def experiment(request):
    context = {
        'difficulty': get_difficulty(),
        'directions': course_model.Direction.objects.filter(status=Status.NORMAL)
    }
    return render(request, 'experiment/cms/experiments.html', context)


def direction_detail(request, direction_id):
    context = {
        'mode': 1
    }

    direction_id = int(direction_id)
    if direction_id == 0:
        context['mode'] = 0
    else:
        context['direction'] = course_model.Direction.objects.get(id=direction_id)

    return render(request, 'course/cms/direction_detail.html', context)


def course_detail(request, course_id):
    context = {
        'mode': 1,
        'directions': course_model.Direction.objects.filter(status=Status.NORMAL)
    }

    course_id = int(course_id)
    if course_id == 0:
        context['mode'] = 0
    else:
        context['course'] = course_model.Course.objects.get(id=course_id)

    context['difficulty'] = get_difficulty()

    return render(request, 'course/cms/course_detail.html', context)


def experiment_detail(request, experiment_id):
    context = {
        'mode': 1,
        'directions': course_model.Direction.objects.filter(status=Status.NORMAL)
    }

    experiment_id = int(experiment_id)
    if experiment_id == 0:
        context['mode'] = 0
    else:
        context['course'] = course_model.Course.objects.get(id=experiment_id)

    context['difficulty'] = get_difficulty()

    return render(request, 'experiment/cms/experiment_detail.html', context)


def lesson(request, course_id):
    course_obj = Course.objects.get(id=course_id)
    context = {
        'course_id' : course_id,
        'course': course_obj
    }

    return render(request, 'course/cms/lessons.html', context)


def exp_lesson(request, experiment_id):
    experiment_obj = Course.objects.get(id=experiment_id)
    context = {
        'experiment_id' : experiment_id,
        'experiment': experiment_obj
    }

    return render(request, 'experiment/cms/lessons.html', context)


def lesson_detail(request, course_id, lesson_id):
    context = {
        'mode': 1,
        'course_id':course_id
    }

    course_id = int(lesson_id)
    if course_id == 0:
        context['mode'] = 0
    else:
        context['lesson'] = course_model.Lesson.objects.get(id=lesson_id)

    return render(request, 'course/cms/lesson_detail.html', context)


def exp_lesson_detail(request, experiment_id, lesson_id):
    context = {
        'mode': 1,
        'experiment_id':experiment_id
    }

    course_id = int(lesson_id)
    if course_id == 0:
        context['mode'] = 0
    else:
        context['lesson'] = course_model.Lesson.objects.get(id=lesson_id)

    return render(request, 'experiment/cms/lesson_detail.html', context)


def custom_lesson_detail(request, lesson_id):
    if request.method == 'PUT':
        params = QueryDict(request.body)
        lesson = Lesson.objects.get(id=lesson_id)
        if "pdf" in params:
            if lesson.pdf:
                lesson.pdf.delete()
            lesson.save()
        if "video" in params:
            if lesson.video:
                lesson.video.delete()
            lesson.save()
    return HttpResponse(None, status=200)


def auth_class(request, course_id):

    context = {
        'course_id':course_id,
        'facultys' : auth_api.get_faculty(),
        'majors' : auth_api.get_major(),
        'url_list_url': reverse("cms_course:course"),
        'query_auth_url': reverse("cms_course:api:course-get-auths", kwargs={'pk':course_id}),
        'modify_auth_url': reverse("cms_course:api:course-set-auths", kwargs={'pk':course_id}),
    }

    return cms_views.auth_class(request, context)


def practice_categories(request, type_id):
    try:
        type_id = int(type_id)
        categorys = get_category_by_type(type_id)
    except Exception, e:
        categorys = []
    return JsonResponse({"data": categorys})


def report_list(request, experiment_id, lesson_id):
    lesson = Lesson.objects.get(id=lesson_id)
    context = {"lesson": lesson, "experiment_id": experiment_id}
    return render(request, 'experiment/cms/report_list.html', context)


def report_detail(request, report_id):
    note = Note.objects.get(id=report_id)
    context = {"note": note}
    return render(request, 'experiment/cms/report_detail.html', context)
