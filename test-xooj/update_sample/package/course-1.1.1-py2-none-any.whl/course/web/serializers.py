# -*- coding: utf-8 -*-
from rest_framework import serializers

from course import models as course_models


class DirectionSerializer(serializers.ModelSerializer):
    class Meta:
        model = course_models.Direction
        fields = ('cn_name', 'en_name')
