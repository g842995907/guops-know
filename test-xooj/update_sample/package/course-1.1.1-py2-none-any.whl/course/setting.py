# -*- coding: utf-8 -*-

from __future__ import unicode_literals

from django.utils.translation import gettext

from common_framework.setting.settings import APISettings

DEFAULTS = {
    'MENU': (
        {
            'name': gettext('课程'),
            'parent': None,
            'icon': {
                'style': 'font awesonme',
                'value': 'fa fa-book',
            }
        },
        {
            'name': gettext('理论课程'),
            'parent': gettext('课程'),
            'href': 'course',
        },
        {
            'name': gettext('实验课程'),
            'parent': gettext('课程'),
            'href': 'experiment',
        }
    ),
    'WEB_MENU': (
        {
            'name': gettext('课程'),
            'parent': None,
            'href': 'list'
        },
        {
            'name': gettext('理论课程'),
            'parent': gettext('课程'),
            'href': 'theory_list',
            'icon': {'value': 'oj-icon oj-icon-E900 font25P'}
        },
        {
            'name': gettext('实验课程'),
            'parent': gettext('课程'),
            'href': 'experiment_list',
            'icon': {'value': 'oj-icon oj-icon-E923 font25P'}
        },
    ),
    'SLUG': 'course',
    'RELY_ON': [
    ],
}

IMPORT_STRINGS = ()

api_settings = APISettings('COURSE', None, DEFAULTS, IMPORT_STRINGS)
