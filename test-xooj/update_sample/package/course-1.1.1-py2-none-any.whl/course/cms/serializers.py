# -*- coding: utf-8 -*-
from rest_framework import serializers

from course import models as course_models
from common_auth.serializers import ClassesSerializer
from common_framework.utils.constant import Status
from common_framework.utils.image import save_image
from x_note.models import Note


class DirectionSerializer(serializers.ModelSerializer):
    class Meta:
        model = course_models.Direction
        fields = ('cn_name', 'en_name', 'last_edit_time', 'last_edit_user', 'id')


class CourseSerializer(serializers.ModelSerializer):
    count = serializers.SerializerMethodField()
    direction_i18n_name = serializers.SerializerMethodField()
    direction_cn_name = serializers.SerializerMethodField()
    direction_en_name = serializers.SerializerMethodField()
    auth_count = serializers.SerializerMethodField()
    auth_classes = ClassesSerializer(many=True, read_only=True)

    def get_count(self, obj):
        return course_models.Lesson.objects.filter(course=obj).filter(status=Status.NORMAL).count()

    def get_direction_i18n_name(self, obj):
        try:
            language = self.context.get("request").LANGUAGE_CODE
            if language != "zh-hans":
                return obj.direction.en_name
        except Exception, e:
            pass
        return obj.direction.cn_name

    def get_direction_cn_name(self, obj):
        return obj.direction.cn_name

    def get_direction_en_name(self, obj):
        return obj.direction.en_name

    def get_auth_count(self, obj):
        return len(obj.auth_classes.all())

    def to_internal_value(self, data):
        full_logo_name = data.get('logo', None)
        data._mutable = True
        if full_logo_name:
            data['logo'] = save_image(full_logo_name)
        data._mutable = False
        ret = super(CourseSerializer, self).to_internal_value(data)
        return ret

    class Meta:
        model = course_models.Course
        fields = ('name', 'auth_count', 'hash', 'direction_i18n_name', 'type',
                  'last_edit_time', 'last_edit_user', 'id', 'direction_cn_name',
                  'direction_en_name', 'direction', 'public', 'creater',
                  'introduction', 'logo', 'difficulty', 'count', 'auth_classes', 'lock')


class LessonSerializer(serializers.ModelSerializer):
    course_name = serializers.SerializerMethodField()
    report_count = serializers.SerializerMethodField()

    def get_report_count(self, obj):
        return Note.objects.filter(resource=obj.hash).filter(status=Status.NORMAL).count()

    def get_course_name(self, obj):
        if obj.course:
            return obj.course.name
        return None

    class Meta:
        model = course_models.Lesson
        fields = (
            'name', 'course_name', 'course', 'public',
            'id', 'pdf', 'video', 'practice', 'homework',
            'practice_name', 'homework_name', 'hash', 'report_count'
        )
