from django.conf.urls import url, include

from common_framework.utils.rest.routers import get_default_router

from course.cms import viewset, views

viewsets = (
    viewset.DirectionViewSet,
    viewset.CourseViewSet,
    viewset.LessonViewSet,
)

router = get_default_router(viewsets)

urlpatterns = [
    url(r'^api/', include(router.urls, namespace='api')),

    url(r'^direction/$', views.direction, name='direction'),
    url(r'^direction/(?P<direction_id>[a-z|0-9]+)/$', views.direction_detail, name='direction_detail'),

    url(r'^course/$', views.course, name='course'),
    url(r'^course/(?P<course_id>[a-z|0-9]+)/$', views.course_detail, name='course_detail'),

    url(r'^experiment/$', views.experiment, name='experiment'),
    url(r'^experiment/(?P<experiment_id>[a-z|0-9]+)/$', views.experiment_detail, name='experiment_detail'),

    url(r'^lesson_list/(?P<course_id>[a-z0-9]+)/$', views.lesson, name='lesson'),
    url(r'^lesson/(?P<course_id>[a-z0-9]+)/(?P<lesson_id>[a-z0-9-]+)/$', views.lesson_detail, name='lesson_detail'),
    url(r'^lesson/(?P<lesson_id>[a-z|0-9]+)/custom_detail/$',
        views.custom_lesson_detail, name='custom_lesson_detail'),

    url(r'^exp_lesson_list/(?P<experiment_id>[a-z0-9]+)/$', views.exp_lesson, name='exp_lesson'),
    url(r'^exp_lesson/(?P<experiment_id>[a-z0-9]+)/(?P<lesson_id>[a-z0-9-]+)/$', views.exp_lesson_detail, name='exp_lesson_detail'),

    url(r'^auth_class/(?P<course_id>[a-z0-9]+)/$', views.auth_class, name='auth_class'),
    url(r'^practice_categories/(?P<type_id>[a-z0-9]+)/$', views.practice_categories, name='practice_categories'),

    url(r'^reports/(?P<experiment_id>[a-z0-9]+)/(?P<lesson_id>[a-z0-9-]+)/$', views.report_list, name='report_list'),
    url(r'^report/detail/(?P<report_id>[a-z0-9]+)/$', views.report_detail, name='report_detail'),
]
