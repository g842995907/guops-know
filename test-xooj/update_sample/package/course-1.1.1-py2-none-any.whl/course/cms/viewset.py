# -*- coding: utf-8 -*-
from rest_framework import filters, viewsets
from rest_framework.permissions import IsAuthenticated

from common_framework.utils.constant import Status
from common_framework.utils.rest import mixins as common_mixins
from common_framework.utils.rest.request import RequestData

from course.cms import serializers
from course import models as course_modules
from course.web import viewset as web_viewsets


class DirectionViewSet(common_mixins.CacheModelMixin,
                       common_mixins.DestroyModelMixin,
                       viewsets.ModelViewSet):
    queryset = course_modules.Direction.objects.filter(status=Status.NORMAL)
    permission_class = (IsAuthenticated,)
    serializer_class = serializers.DirectionSerializer
    filter_backends = (filters.SearchFilter, filters.OrderingFilter)
    ordering_fields = ('last_edit_time',)
    ordering = ('last_edit_time',)
    search_fields = ('cn_name', 'en_name',)

    def sub_perform_create(self, serializer):
        serializer.save(
            last_edit_user=self.request.user
        )
        return True

    def sub_perform_destroy(self, instance):
        instance.status = Status.DELETE
        instance.save()
        return True


class CourseViewSet(common_mixins.CacheModelMixin,
                    common_mixins.PublicModelMixin,
                    common_mixins.DestroyModelMixin,
                    common_mixins.AuthsMixin,
                    viewsets.ModelViewSet):
    queryset = course_modules.Course.objects.filter(status=Status.NORMAL)
    permission_class = (IsAuthenticated,)
    serializer_class = serializers.CourseSerializer
    related_cache_class = (web_viewsets.CourseViewSet,)

    filter_backends = (filters.SearchFilter, filters.OrderingFilter)
    ordering_fields = ('id',)
    ordering = ('-id',)
    search_fields = ('name',)

    def sub_perform_create(self, serializer):
        serializer.save(
            last_edit_user=self.request.user,
            creater=self.request.user
        )
        return True

    def sub_perform_destroy(self, instance):
        instance.status = Status.DELETE
        instance.save()
        return True

    def sub_perform_update(self, serializer):
        if serializer.validated_data.get('public') is None:
            serializer.validated_data['public'] = False

        serializer.save()
        return True

    def get_queryset(self):
        queryset = self.queryset

        data = RequestData(self.request, is_query=True)
        type = data.get('search_type', int)
        if type is not None:
            queryset = queryset.filter(type=type)

        direction = data.get('search_direction', int)
        if direction is not None:
            queryset = queryset.filter(direction=direction)

        difficulty = data.get('search_difficulty')
        if difficulty:
            queryset = queryset.filter(difficulty=difficulty)

        return queryset

    def get_faculty_major_objs(self, request, course_id, faculty=None, major=None):
        if not course_id:
            return []

        course = course_modules.Course.objects.filter(id=course_id).first()
        if not course:
            return []

        return course


class LessonViewSet(common_mixins.CacheModelMixin,
                    common_mixins.PublicModelMixin,
                    common_mixins.DestroyModelMixin,
                    viewsets.ModelViewSet):
    queryset = course_modules.Lesson.objects.filter(status=Status.NORMAL)
    permission_class = (IsAuthenticated,)
    serializer_class = serializers.LessonSerializer
    filter_backends = (filters.SearchFilter, filters.OrderingFilter)
    related_cache_class = (web_viewsets.LessonViewSet,)
    ordering_fields = ('id',)
    ordering = ('-id',)
    search_fields = ('name',)

    def sub_perform_create(self, serializer):
        serializer.save(
        )
        return True

    def sub_perform_destroy(self, instance):
        instance.status = Status.DELETE
        instance.save()
        return True

    def get_queryset(self):
        queryset = self.queryset

        data = RequestData(self.request, is_query=True)
        course_id = data.get('course_id', int)
        if course_id is not None:
            queryset = queryset.filter(course__id=course_id)

        return queryset

    def sub_perform_update(self, serializer):
        if serializer.validated_data.get('public') is None:
            serializer.validated_data['public'] = False

        serializer.save()
        return True
