# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import uuid

from django.db import models

from common_auth.models import User, Classes
from common_framework.utils.constant import Status
from common_framework.utils.enum import enum
from common_framework.models import ShowLock

from practice.api import get_task_detail


class Direction(models.Model):
    cn_name = models.CharField(max_length=50, unique=True)
    en_name = models.CharField(max_length=50, default=None, null=True)
    last_edit_time = models.DateTimeField(auto_now=True)
    last_edit_user = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    status = models.PositiveIntegerField(default=Status.NORMAL)

    def __unicode__(self):
        return '%s' % self.cn_name

    class Meta:
        db_table = 'course_category'


def course_hash():
    return "{}.course".format(uuid.uuid4())


def lesson_hash():
    return "{}.lesson".format(uuid.uuid4())


class Course(ShowLock):
    # 课程难度
    difficulty = enum(
        INTRUDCTION=0,
        INCREASE=1,
        EXPERT=2
    )
    # 课程难度
    type = enum(
        THEORY=0,
        EXPERIMENT=1,
    )
    name = models.CharField(max_length=50)
    hash = models.CharField(max_length=100, null=True, default=course_hash)
    direction = models.ForeignKey(Direction, null=True, on_delete=models.SET_NULL)
    last_edit_user = models.ForeignKey(User, null=True, on_delete=models.SET_NULL, related_name='course_last_edit_user')
    last_edit_time = models.DateTimeField(auto_now=True)
    public = models.BooleanField(default=True)
    creater = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='course_creater')
    introduction = models.TextField(null=True, blank=True)
    logo = models.FileField(upload_to='course/logo', null=True, default=None)
    difficulty = models.PositiveIntegerField(default=difficulty.INTRUDCTION)
    type = models.PositiveIntegerField(default=type.THEORY)
    auth_classes = models.ManyToManyField(Classes)
    status = models.PositiveIntegerField(default=Status.NORMAL)

    def __unicode__(self):
        return '%s' % self.name


class Lesson(models.Model):
    course = models.ForeignKey(Course, null=True, on_delete=models.SET_NULL)
    name = models.CharField(max_length=200)
    pdf = models.FileField(upload_to='course/pdf', null=True)
    video = models.FileField(upload_to='course/video', null=True)
    practice = models.CharField(max_length=200, null=True)
    homework = models.CharField(max_length=200, null=True)
    hash = models.CharField(max_length=100, null=True, default=lesson_hash)
    status = models.PositiveIntegerField(default=Status.NORMAL)
    public = models.BooleanField(default=True)

    def __unicode__(self):
        return '%s' % self.name

    def practice_name(self):
        if not self.practice:
            return ""
        try:
            hash, type_id = self.practice.split(".")
            if type_id:
                task_detail = get_task_detail(type_id, self.practice, backend=True)
                return task_detail.get("title_dsc")
        except Exception, e:
            return self.practice

    def homework_name(self):
        if not self.homework:
            return ""
        try:
            hash, type_id = self.homework.split(".")
            if type_id:
                task_detail = get_task_detail(type_id, self.homework, backend=True)
                return task_detail.get("title_dsc")
        except Exception, e:
            return self.homework
